name = input("what is your name?\n")
print ("hi, $s." % name)
#спрашивает имя 