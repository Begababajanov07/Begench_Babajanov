def greet(name):
    print ('Hello', name)

greet('Jack')
greet('Jill')
greet('Bob')
#приветствие